严格道路拓扑修复版
输入文件：roads.geojson、nodes.geojson、overpass_response.json
运行环境：Python 3（只用标准库，无需 pip 安装）
命令：
python fix_road_topology_strict.py --roads roads.geojson --nodes nodes.geojson --raw overpass_response.json --out output

输出：
roads_topology_strict.geojson / .csv
nodes_topology_strict.geojson / .csv

规则：只在多条道路 way 共同引用的同一个 OSM node ID 处切分，不以坐标相交代替真实节点共享。
注意：本程序修复的是拓扑结构，不负责确认现场道路开放状态、门禁、通行权限或救援车辆限行。
数据来源：OpenStreetMap / Overpass API；数据许可 ODbL。分发时请保留来源与许可声明。
