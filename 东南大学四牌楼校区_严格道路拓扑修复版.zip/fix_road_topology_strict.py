#!/usr/bin/env python3
# Strict OSM topology repair using shared OSM node IDs.
# python fix_road_topology_strict.py --roads roads.geojson --nodes nodes.geojson --raw overpass_response.json --out output
import argparse, json, math, os, csv
from collections import defaultdict, Counter

def haversine(a,b):
    lon1,lat1=map(math.radians,a[:2]); lon2,lat2=map(math.radians,b[:2])
    h=math.sin((lat2-lat1)/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 6371008.8*2*math.asin(math.sqrt(h))
def save_geo(path,features):
    with open(path,"w",encoding="utf-8") as f: json.dump({"type":"FeatureCollection","features":features},f,ensure_ascii=False,indent=2)
def save_csv(path,features):
    fields=[]
    for ft in features:
        for k in ft["properties"]:
            if k not in fields: fields.append(k)
    fields.append("coordinates_lon_lat")
    with open(path,"w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for ft in features:
            row=ft["properties"].copy()
            row["coordinates_lon_lat"]=json.dumps(ft["geometry"]["coordinates"],ensure_ascii=False,separators=(",",":"))
            w.writerow(row)
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--roads",required=True); ap.add_argument("--nodes",required=True)
    ap.add_argument("--raw",required=True); ap.add_argument("--out",default="topology_strict")
    a=ap.parse_args()
    roads=json.load(open(a.roads,encoding="utf-8"))
    nodes=json.load(open(a.nodes,encoding="utf-8"))
    raw=json.load(open(a.raw,encoding="utf-8"))
    ways={e["id"]:e for e in raw["elements"] if e["type"]=="way"}
    raw_nodes={e["id"]:e for e in raw["elements"] if e["type"]=="node"}
    node_id_by_osm={int(f["properties"]["osm_node_id"]):f["properties"]["node_id"] for f in nodes["features"] if f["properties"].get("osm_node_id") is not None}
    way_ids={int(f["properties"]["osm_way_id"]) for f in roads["features"]}
    missing=[wid for wid in way_ids if wid not in ways]
    if missing: raise SystemExit(f"原始响应缺少 {len(missing)} 条道路 way：{missing[:10]}")
    used=defaultdict(set)
    for wid in way_ids:
        for nid in ways[wid]["nodes"]: used[nid].add(wid)
    shared={nid for nid,owners in used.items() if len(owners)>1}
    result=[]
    for ft in roads["features"]:
        p0=ft["properties"]; wid=int(p0["osm_way_id"]); seq=ways[wid]["nodes"]
        absent=[n for n in seq if n not in raw_nodes or n not in node_id_by_osm]
        if absent: raise SystemExit(f"way {wid} 的节点在 raw 或 nodes.geojson 中缺失：{absent[:10]}")
        coords=[[raw_nodes[n]["lon"],raw_nodes[n]["lat"]] for n in seq]
        cuts=[0]+[i for i in range(1,len(seq)-1) if seq[i] in shared]+[len(seq)-1]
        cuts=sorted(set(cuts)); parts=[(x,y) for x,y in zip(cuts[:-1],cuts[1:]) if y>x]
        for j,(x,y) in enumerate(parts,1):
            p=p0.copy()
            if len(parts)>1:
                p["source_road_id"]=p0["road_id"]; p["road_id"]=f'{p0["road_id"]}-T{j:03d}'
            p["from_node"]=node_id_by_osm[seq[x]]; p["to_node"]=node_id_by_osm[seq[y]]
            p["length_m"]=round(sum(haversine(u,v) for u,v in zip(coords[x:y],coords[x+1:y+1])),2)
            p["topology_method"]="shared_osm_node_id"; p["topology_verified_osm_node_id"]=True
            p["osm_from_node_id"]=seq[x]; p["osm_to_node_id"]=seq[y]
            result.append({"type":"Feature","properties":p,"geometry":{"type":"LineString","coordinates":coords[x:y+1]}})
    os.makedirs(a.out,exist_ok=True)
    save_geo(os.path.join(a.out,"roads_topology_strict.geojson"),result)
    save_geo(os.path.join(a.out,"nodes_topology_strict.geojson"),nodes["features"])
    save_csv(os.path.join(a.out,"roads_topology_strict.csv"),result)
    save_csv(os.path.join(a.out,"nodes_topology_strict.csv"),nodes["features"])
    print(f"完成：{len(result)} 条道路段；按 {len(shared)} 个共享 OSM node ID 拆分。")
if __name__=="__main__": main()
